class NumbersController < ApplicationController
  def input; end

  def result
    @numbers = NumbersResult.new(numbers_params)
  end

  private

  def numbers_params
    params.permit(:stop_number)
  end

end
