class NumbersResult
	include ActiveModel::Model # примешиваем методы для модели ActiveModel
	include ActiveModel::Validations # примешиваем методы для валидаций из ActiveModel

	attr_accessor :stop_number

	validates :stop_number, presence: { message: 'не может быть пустым' } # проверка на обязательное наличие полей
	validates :stop_number, numericality: { only_integer: true, message: 'должно быть целым числом' } # проверка на число

	def result
		numbers = (1..stop_number.to_i).select { |number| automorphic?(number) }
	end

	def automorphic?(number)
		sqr_number = number * number
		digits = number.to_s.size
		number == sqr_number % (10**digits)
	end
end