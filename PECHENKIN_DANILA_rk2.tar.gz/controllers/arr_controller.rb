# frozen_string_literal: true

# my doc
class ArrController < ApplicationController
  def input; end

  def view
    user_input = params[:user_input]
    init(user_input)

    @min_item = @array.min
    @max_item = @array.max

    if @max_item.zero?
      @div = 'макс. элемент в массиве - ноль.'
    else
      @div = @min_item / @max_item
      @changed_array = inserting(@div)
    end
  end

  private

  def inserting(item)
    neg_item = @array.find(&:negative?)
    if neg_item.nil?
      result = "В массиве нет отриц. чисел, вставить #{@div} некуда."
    else
      index = @array.find_index(@array.find(&:negative?))
      result = []
      @array.each { |i| result << i }
      result[index] = item
    end
    result
  end

  def init(user_input)
    @array = []
    user_input.split.each do |item|
      if number?(item)
        @array << item.to_f
      else
        flash[:notice] = "Элемент '#{item}' не число. Повторите ввод."
        redirect_to root_path
        break
      end
    end
  end

  def number?(item)
    item.to_f.to_s == item || item.to_i.to_s == item
  end
end
